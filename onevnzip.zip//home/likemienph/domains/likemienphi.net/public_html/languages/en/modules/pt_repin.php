<?
if(! defined('BASEPATH') ){ exit('Unable to view file.'); }

$lang['repin_01'] = 'URL must be something like: http://pinterest.com/pin/<b>PIN-ID</b>';
$lang['repin_02'] = 'Pin already added!';
$lang['repin_03'] = 'This pinterest pin doesn\'t exists!';
$lang['repin_04'] = 'Pin was successfully added!';
$lang['repin_05'] = 'Repin';
$lang['repin_06'] = 'Confirm';
$lang['repin_07'] = 'skip';
$lang['repin_08'] = 'Repin page and close opened window...';
$lang['repin_09'] = 'We cannot contact pinterest...';
$lang['repin_10'] = 'SUCCESS!';
$lang['repin_11'] = ' <b>coins</b> were added to your account!';
$lang['repin_12'] = 'Pinterest says you haven\'t repined this page!';
$lang['repin_13'] = 'SUCCESS! You skipped this pin!';

// Add Page
$lang['repin_url'] = 'Pin URL';
$lang['repin_url_desc'] = 'Add your pin url here';
?>
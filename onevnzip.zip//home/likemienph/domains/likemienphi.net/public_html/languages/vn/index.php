<?php
/* VietNam language pack for PES Pro by XF_UG*/
$c_lang['active'] = '1'; 		// Set 0 to disable this language

$c_lang['lang'] 	= 'VietNam';	// Language name
$c_lang['code'] 	= 'vn';			// This must be the same with folder name
$c_lang['vers'] 	= '1.9.1';		// Version
$c_lang['charset'] 	= 'UTF-8';		// Charset

// Do no edit these lines
$c_lang[$c_lang['code'].'_charset'] = $c_lang['charset'];
?>
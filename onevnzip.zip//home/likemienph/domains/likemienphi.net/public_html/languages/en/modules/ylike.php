<?
if(! defined('BASEPATH') ){ exit('Unable to view file.'); }

$lang['ylike_01'] = 'Video already added!';
$lang['ylike_02'] = 'Please enter a valid Youtube link!';
$lang['ylike_03'] = 'Video added successfully!';
$lang['ylike_04'] = 'Press "Like" on the video, then press "Like" on Youtube\'s page. After that, press "Confirm".';
$lang['ylike_05'] = 'Like';
$lang['ylike_06'] = 'Confirm';
$lang['ylike_07'] = 'skip';
$lang['ylike_08'] = 'SUCCESS! You skipped this video!';
$lang['ylike_09'] = 'Like video and close opened window...';
$lang['ylike_10'] = 'We cannot contact Youtube...';
$lang['ylike_11'] = 'Youtube says you aren\'t liked this video!';
$lang['ylike_12'] = 'SUCCESS!';
$lang['ylike_13'] = ' coins were added to your account!';
$lang['ylike_14'] = '<b>ERROR:</b> "Likes" feature must be enabled if you want to add this video!';

// Add Page
$lang['ylike_url'] = 'Video URL';
$lang['ylike_title'] = 'Video Title';
$lang['ylike_url_desc'] = 'Add your video url here';
$lang['ylike_title_desc'] = 'Add your video title here';
?>
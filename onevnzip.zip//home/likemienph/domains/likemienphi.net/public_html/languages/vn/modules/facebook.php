<?
if(! defined('BASEPATH') ){ exit('Unable to view file.'); }

$lang['fb_01'] = 'YBạn không thể thêm hình ảnh Facebook!';
$lang['fb_02'] = 'Page đã thêm thành công!';
$lang['fb_03'] = 'Thành Công! Bạn bỏ qua trang này!';
$lang['fb_04'] = 'Thành Công! Bạn đã nhận được <b>-NUM- coins</b>!';
$lang['fb_05'] = 'Page đã tồn tại, không thể thêm!';
$lang['fb_06'] = 'Lỗi! You have to be logged in to receive coins!';
$lang['fb_07'] = 'Like Page và đóng cửa sổ vừa mở ra.';
$lang['fb_08'] = 'Chúng tôi không thể kết nối với FaceBook';
$lang['fb_09'] = 'Facebook cho biết bạn không thích trang này!';
$lang['fb_10'] = 'Thành Công!';
$lang['fb_11'] = ' <b>coins</b> đã được thêm vào tài khoản của bạn!';
$lang['fb_12'] = 'Like';
$lang['fb_13'] = 'Xác nhận';
$lang['fb_14'] = 'Bỏ qua';

// Add Page
$lang['fb_url'] = 'URL';
$lang['fb_title'] = 'Title';
$lang['fb_url_desc'] = 'Thêm địa chỉ của bạn ở đây';
$lang['fb_title_desc'] = 'Thêm tiêu đề trang của bạn ở đây';
?>
<?php
/* English language pack for PES Pro */
$c_lang['active'] = '1'; 		// Set 0 to disable this language

$c_lang['lang'] 	= 'English';	// Language name
$c_lang['code'] 	= 'en';			// This must be the same with folder name
$c_lang['vers'] 	= '1.7.1';		// Version
$c_lang['charset'] 	= 'UTF-8';		// Charset

// Do no edit these lines
$c_lang[$c_lang['code'].'_charset'] = $c_lang['charset'];
?>
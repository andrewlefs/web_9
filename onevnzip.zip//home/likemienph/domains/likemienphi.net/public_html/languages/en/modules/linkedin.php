<?
if(! defined('BASEPATH') ){ exit('Unable to view file.'); }

$lang['lin_01'] = 'Page was successfully added!';
$lang['lin_02'] = 'Page already added!';
$lang['lin_03'] = 'SUCCESS! You have received <b>-NUM- coins</b>!';
$lang['lin_04'] = 'SUCCESS! You skipped this page!';

// Add Page
$lang['lin_url'] = 'URL';
$lang['lin_title'] = 'Title';
$lang['lin_url_desc'] = 'Add your website url here';
$lang['lin_title_desc'] = 'Add your website title here';
?>
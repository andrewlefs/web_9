<?
if(! defined('BASEPATH') ){ exit('Unable to view file.'); }

$lang['b_01'] = 'Trang Bảo Trì';
$lang['b_02'] = 'Tài khoản của bạn đã bị khóa!';
$lang['b_03'] = 'Bạn cần xác nhận email của bạn!';
$lang['b_04'] = 'Tên đăng nhập hoặc mật khẩu sai!';
$lang['b_05'] = 'Đăng Ký';
$lang['b_06'] = 'Hướng Dẫn';
$lang['b_07'] = 'Nạp Vcoin';
$lang['b_08'] = 'Thành viên VIP';
$lang['b_09'] = 'Thưởng hàng ngày';
$lang['b_10'] = 'Phiếu quà tặng';
$lang['b_11'] = 'Chuyển Vcoin';
$lang['b_12'] = 'Kiếm tiền';
$lang['b_13'] = 'Đăng Nhập';
$lang['b_14'] = 'Username / Email';
$lang['b_15'] = 'Password';
$lang['b_16'] = 'Quên mật khẩu?';
$lang['b_17'] = 'Bạn có -NUM- Vcoin!';
$lang['b_18'] = 'Quản lý tài khoản';
$lang['b_19'] = 'Thêm Trang Web';
$lang['b_20'] = 'Quản lý trang';
$lang['b_21'] = 'Tài khoản MXH';
$lang['b_22'] = 'Kiếm Vcoin';
$lang['b_23'] = 'Địa chỉ E-mail đã được xác nhận thành công!';
$lang['b_24'] = 'Sai URL xác nhận!';
$lang['b_25'] = 'Xin vui lòng hoàn thành tất cả các lĩnh vực!';
$lang['b_26'] = 'URL phải chứa http://';
$lang['b_27'] = 'Xin vui lòng không sử dụng ký tự đặc biệt trong URL!';
$lang['b_28'] = 'Tên tiêu đề viết KÝ TỰ KHÔNG DẤU ( Tiếng việt không dấu)';
$lang['b_29'] = 'CPC phải từ -MIN- và -MAX- Vcoin!';
$lang['b_30'] = 'Thêm trang';
$lang['b_31'] = 'Thể loại bạn muốn tăng';
$lang['b_32'] = 'Địa chỉ URL (VD: http://facebook.com/HoanggiaInc )';
$lang['b_33'] = 'Tiêu đề ( Nên ghi tiếng việt không dấu)';
$lang['b_34'] = 'Thêm địa chỉ của bạn ở đây';
$lang['b_35'] = 'Thêm tiêu đề trang của bạn ở đây';
$lang['b_36'] = 'Số Vcoin mất đi / 1 lần trao đổi';
$lang['b_37'] = 'Thêm Trang Web';
$lang['b_38'] = '<b>-NUM-</b> tiền thưởng ngày đã cộng vào tài khoản của bạn!';
$lang['b_39'] = 'Bạn đã có tiền thưởng của bạn hôm nay!';
$lang['b_40'] = 'Nhận -NUM- Vcoin mỗi ngày!';
$lang['b_41'] = 'Bạn đã có tiền thưởng của bạn ngày hôm nay! Nhận tiếp sau <b>-TIME-</b>!';
$lang['b_42'] = 'Vcoin';
$lang['b_43'] = 'Không có tiền gói sẵn để bán!';
$lang['b_44'] = 'Loading';
$lang['b_45'] = 'Chờ đợi cho bộ đếm thời gian và sau đó trang web của bạn sẽ được xác nhận tự động.';
$lang['b_46'] = 'Xin vui lòng chờ -TIME- giây.';
$lang['b_47'] = 'Liên Hệ';
$lang['b_48'] = 'Tên của bạn';
$lang['b_49'] = 'Email của bạn';
$lang['b_50'] = 'Lời nhắn của bạn';
$lang['b_51'] = 'Mã bảo mật';
$lang['b_52'] = 'Gửi';
$lang['b_53'] = 'Tin nhắn đã được gửi thành công!';
$lang['b_54'] = '<b>Lỗi:</b> Bạn đã cung cấp một mã số bảo mật không hợp lệ!';
$lang['b_55'] = '<b>Lỗi:</b> Vui lòng nhập tên thật của bạn!';
$lang['b_56'] = '<b>Lỗi:</b> Vui lòng nhập địa chỉ email của bạn!';
$lang['b_57'] = '<b>Lỗi:</b> Vui lòng nhập tin nhắn của bạn!';
$lang['b_58'] = 'Ok';
$lang['b_59'] = 'Phiếu quà tặng';
$lang['b_60'] = '<b>Thành Công!</b> Bạn đã nhận được <b>-NUM- Vcoin</b>!';
$lang['b_61'] = '<b>Lỗi:</b> Mã thưởng không tồn tại hoặc đã được sử dụng!';
$lang['b_62'] = 'If you have received an coupon code, you can validate it here.';
$lang['b_63'] = '<b>Lỗi:</b> Mật khẩu của bạn không tồn tại hoặc sai!';
$lang['b_64'] = 'Thay đổi mật khẩu thành công!';
$lang['b_65'] = '<b>Lỗi:</b> Hãy nhập địa chỉ email hợp lệ!';
$lang['b_66'] = '<b>Lỗi:</b> Địa chỉ Email này đã được đang ký!';
$lang['b_67'] = 'Thay đổi email thành công';
$lang['b_68'] = 'Thay đổi Mật khẩu';
$lang['b_69'] = 'Thay đổi Email';
$lang['b_70'] = 'Email';
$lang['b_71'] = 'Mật khẩu mới';
$lang['b_72'] = 'Lập lại mật khẩu';
$lang['b_73'] = 'Bạn không thể chặn trang này!';
$lang['b_74'] = 'Website đã cập nhật thành công';
$lang['b_75'] = 'Tình trạng';
$lang['b_76'] = 'Mở';
$lang['b_77'] = 'Tắt';
$lang['b_78'] = 'Cấm';
$lang['b_79'] = 'Cập nhật';
$lang['b_80'] = 'Bạn có chắc bạn muốn xóa trang web của bạn?';
$lang['b_81'] = 'Xóa';
$lang['b_82'] = 'Thống Kê';
$lang['b_83'] = 'Chào mừng';
$lang['b_84'] = ' Đăng ký VIP tặng ngay Vcoin <br/>
Hệ thống trao đổi Like, Sub, Follow...<br/> miễn phí

';
$lang['b_85'] = '
* Đăng ký "THÀNH VIÊN VIP" ngay để nhận được nhiều ưu đãi<br/>
* Hãy đọc kỹ "HƯỚNG DẪN" trước khi sử dụng hệ thống <br/>
* CPC - chính là giá mỗi like mà bạn trả. ví dụ 10 Coins/1 Like<br/>
* Hãy Like page của người khác để kiếm Coins về tài khoản<br/>
* "NẠP TIỀN" ngay để mua được nhiều Coins và những ưu đãi khác.
';
$lang['b_86'] = 'Sửa Tài Khoản';
$lang['b_87'] = 'Thoát';
$lang['b_88'] = 'Bạn có -NUM- Vcoin';
$lang['b_89'] = 'và -SUM- ';
$lang['b_90'] = 'Find us on Facebook';
$lang['b_91'] = 'Những gì bạn có thể trao đổi với chúng tôi?';
$lang['b_92'] = 'Chúng tôi hỗ trợ hầu hết các mạng xã hội.';
$lang['b_93'] = 'Chọn';
$lang['b_94'] = 'Số lần trao đổi';
$lang['b_95'] = 'CPC';
$lang['b_96'] = 'Sửa';
$lang['b_97'] = 'Rút tiền';
$lang['b_98'] = 'Lỗi: The minimum payout is <b>$-MIN-</b>!';
$lang['b_99'] = 'Lỗi: You don\'t have enough money!';
$lang['b_100'] = 'Lỗi: Enter a valid email address!';
$lang['b_101'] = 'Your request was received with Thành Công!';
$lang['b_102'] = 'QUY ĐỊNH RÚT TIỀN: <br />Bạn chỉ có thể rút tiền khi tài khoản của bạn có số dư >= -SUM-$.<br />
Chúng Tôi sẽ xử lý thanh toán của bạn trong vòng 1 tuần kể từ ngày bạn gửi yêu cầu.<br />
Like miễn phí cảm ơn sự hợp tác của các bạn, sự hợp tác này chính là sự phát triển bền vững của chúng Tôi trong tương lai.<br />
Để khuyến khích và tôn vinh những thành viên tích cực tham gia trên hệ thống, chúng Tôi sẽ trả phí cho những thành quả của các bạn, tuy nhiên các bạn cũng cần phải tuân thủ vô điều kiện những quy định của chúng Tôi, cụ thể:<br />
- Thành viên chỉ có thể rút tiền sau 30 ngày hoạt động kể từ ngày đăng ký.<br />
- Mỗi thành viên muốn rút được tiền thì phải add 1 page vào hệ thống và page này phải có tối thiểu 100 trao đổi (like hoăc follow hoặc Plus hoặc Sub ...)<br />
- Số tiền tối thiểu bạn có thể rút là >=3 $<br />
- Hình thức nhận tiền:<br />
+ Nhận tiền qua tài khoản Bảo Kim<br />
+ Nhận tiền bằng thẻ Viettel, Vinaphone, Mobilphone (với số tiền nhỏ hơn hoặc bằng 20$)<br />
+ Nhận tiền qua chuyển khoản ngân hàng (với số tiền lớn hơn 20$, phí chuyển khoản thành viên phải trả)<br />
- Thành viên nhận được tiền trong vòng 10 ngày kể từ khi chúng Tôi nhận được yêu cầu rút tiền.<br />
- Chúng Tôi sẽ xác nhận thông tin thành viên: số điện thoại,email, địa chỉ, chứng minh thư nhân dân.<br />
- Thông tin tài khoản trên Likemienphi.com phải trùng với thông tin thanh toán: Điện thoại, email<br />
- Mỗi thành viên chỉ được rút tiền 1 lần trong 1 tháng.<br />
- Thời gian gửi yêu cầu rút tiền từ ngày mùng 1 đến mùng 10 của tháng đó.<br />
- Những thành viên nào rút tiền sai quy định thì toàn bộ số tiền rút sẽ bị mất và không được cộng ngược lại vào tài khoản của bạn.<br />
- Danh sách các thành viên nhận được tiền sẽ được đăng tải tại mục \"Thông Báo \" của hệ thống.<br />
Mọi quy định của chúng Tôi nhằm tạo ra một sân chơi trong sạch công bằng cho tất cả các thành viên.';





$lang['b_103'] = 'Amount';
$lang['b_104'] = 'Payment Email';
$lang['b_105'] = 'Paypal';
$lang['b_106'] = 'Date';
$lang['b_107'] = 'Waiting';
$lang['b_108'] = 'Rejected';
$lang['b_109'] = 'Paid';
$lang['b_110'] = 'Lỗi: Email address is not registered in our database!';
$lang['b_111'] = 'Thành Công! Please check your email inbox!';
$lang['b_112'] = 'Recover Password';
$lang['b_113'] = 'Đặt banner/link của chúng tôi trên website của bạn và bắt đầu kiếm tiền';
$lang['b_114'] = '-NUM- Xu cho mỗi thành viên đó đăng ký lên website của chúng tôi';
$lang['b_115'] = '$-SUM- Tiền thưởng cho bạn';
$lang['b_116'] = '-NUM- % cho mỗi giao dịch thành công từ thành viên mà bạn đã giới thiệu';
$lang['b_117'] = 'Link giới thiệu';
$lang['b_118'] = 'HTML Code';
$lang['b_119'] = 'Total Referrals';
$lang['b_120'] = 'Unpaid Earnings';
$lang['b_121'] = 'Referrals';
$lang['b_122'] = 'Tên đăng nhập (Viết liền và không dấu)';
$lang['b_123'] = 'Active?';
$lang['b_124'] = 'Yes';
$lang['b_125'] = 'No';
$lang['b_126'] = 'from <b>-NUM-</b> referrals';
$lang['b_127'] = 'Tên đăng nhập hoặc email đã đăng ký!';
$lang['b_128'] = 'Chúng tôi cho phép chỉ 1 tài khoản cho mỗi địa chỉ IP!';
$lang['b_129'] = 'Xin vui lòng nhập tên người dùng hợp lệ, Tên đăng nhập không có dấu và phải viết liền nhau!';
$lang['b_130'] = 'Kích hoạt tài khoản của bạn';
$lang['b_131'] = 'Thành Công!';
$lang['b_132'] = 'Bạn cần phải xác nhận địa chỉ email của bạn bây giờ!';
$lang['b_133'] = 'Giờ bạn có thể Đăng Nhập vào website!';
$lang['b_134'] = 'Registrations are currently disabled!';
$lang['b_135'] = 'Active Members';
$lang['b_136'] = 'Online Members';
$lang['b_137'] = 'Banned Members';
$lang['b_138'] = 'Total Members';
$lang['b_139'] = 'Members';
$lang['b_140'] = 'Pages';
$lang['b_141'] = 'Clicks';
$lang['b_142'] = 'TOTAL';
$lang['b_143'] = 'Số Vcoin';
$lang['b_144'] = 'Khi load hết thời gian bạn sẽ được -NUM- Vcoin!';
$lang['b_145'] = 'Bỏ qua';
$lang['b_146'] = '<b>Lỗi:</b> You don\'t have enough Vcoin!';
$lang['b_147'] = '<b>Lỗi:</b> This user is disabled or doesn\'t exists!';
$lang['b_148'] = '<b>Lỗi:</b> Vcoin amount must be between 10 and -MAX- Vcoin!';
$lang['b_149'] = 'You have sent -SENT- Vcoin and <b>-USER-</b> received <b>-RECEIVED-</b> Vcoin (-FEE-% fee)!';
$lang['b_150'] = 'Transfer Vcoin to';
$lang['b_151'] = 'Vcoin amount';
$lang['b_152'] = 'Transfer fee';
$lang['b_153'] = 'Last 10 transfers received';
$lang['b_154'] = 'ID';
$lang['b_155'] = 'Sender';
$lang['b_156'] = 'Vcoin';
$lang['b_157'] = 'There are no transfers received!';
$lang['b_158'] = 'Days';
$lang['b_159'] = 'Your VIP membership expires at';
$lang['b_160'] = 'With VIP you can set <b>CPC up to -MAX- Vcoin</b> and your content will be put above everyone\'s content who isn\'t VIP!';
$lang['b_161'] = 'Please wait while we transfer you to Paypal.';
$lang['b_162'] = 'Earn Vcoin';
$lang['b_163'] = 'Hiện tại chưa có trang nào để like, hãy f5 làm mới để thử lại';
$lang['b_164'] = 'Feel like you need more Vcoin? You can purchase them now!';
$lang['b_165'] = 'Còn chờ gì nữa? Đăng ký miễn phí!';
$lang['b_166'] = 'Get Bonus';
$lang['b_167'] = 'Please enter a valid URL (including http://)';
$lang['b_168'] = 'This ad pack doesn\'t exists!';
$lang['b_169'] = 'This website was already added!';
$lang['b_170'] = 'Thành Công!';
$lang['b_171'] = 'Chỉ chấp nhận file JPG, PNG hoặc GIF!';
$lang['b_172'] = 'Kích thước của banner yêu cầu là 468x60 pixels!';
$lang['b_173'] = 'Add Banner';
$lang['b_174'] = 'Website URL';
$lang['b_175'] = 'Select Banner';
$lang['b_176'] = 'Kích thước của banner yêu cầu 468x60 px';
$lang['b_177'] = 'Ad Pack';
$lang['b_178'] = 'days';
$lang['b_179'] = 'Manage Banners';
$lang['b_180'] = 'Running';
$lang['b_181'] = 'Finished';
$lang['b_182'] = 'Banner';
$lang['b_183'] = 'Impressions';
$lang['b_184'] = 'Clicks';
$lang['b_185'] = 'Actions';
$lang['b_186'] = 'Your ad expire at';
$lang['b_187'] = 'Add more days';
$lang['b_188'] = 'Add more';
$lang['b_189'] = 'Banner Quảng cáo';
$lang['b_190'] = 'Thành Công! We have Thành Công sent your activation email!';
$lang['b_191'] = 'Lỗi! This email address was already confirmed!';
$lang['b_192'] = 'Bạn là thành viên';
$lang['b_193'] = 'FREE';
$lang['b_194'] = 'VIP';
$lang['b_195'] = 'CPC Tối đa';
$lang['b_196'] = 'Nhận thưởng hàng ngày';
$lang['b_197'] = 'Trang được ưu tiên lên đầu';
$lang['b_198'] = 'Pay a small fee';
$lang['b_199'] = 'Mua';
$lang['b_200'] = 'Your have';
$lang['b_201'] = 'Country';
$lang['b_202'] = 'Giới tính';
$lang['b_203'] = 'Nam';
$lang['b_204'] = 'Nữ';
$lang['b_205'] = 'Uncompleted';
$lang['b_206'] = 'Thay đổi thông tin ';
$lang['b_207'] = 'You can change your info -NUM- more times.';
$lang['b_208'] = '<b>Lỗi:</b> Hãy cập nhập giới tính!';
$lang['b_209'] = '<b>Lỗi:</b> Hãy cập nhập country!';
$lang['b_210'] = '<b>Lỗi:</b> You can change your info only -NUM- times!';
$lang['b_211'] = '<b>Thành Công:</b> Bạn có thể đăng nhập vào hệ thống!';
$lang['b_212'] = 'Edit Site';
$lang['b_213'] = 'Receive Clicks From';
$lang['b_214'] = 'All Genders';
$lang['b_215'] = 'Men';
$lang['b_216'] = 'Women';
$lang['b_217'] = 'and';
$lang['b_218'] = 'All Countries';
$lang['b_219'] = '<b>Lỗi:</b> Please select from which genders do you want to receive clicks!';
$lang['b_220'] = '<b>Lỗi:</b> Please select from what countries do you want to receive clicks!';
$lang['b_221'] = '<b>Thành Công:</b> Settings Thành Công saved!';
$lang['b_222'] = '<b>Lỗi:</b> You can change your info only -NUM- times.';
$lang['b_223'] = 'Thay đổi giới tính và quốc gia';
$lang['b_224'] = 'times';
$lang['b_225'] = 'Bạn cần <b>like / follow / subscribe</b> ít nhất <b>-NUM- pages</b> Để nhận được Vcoin hàng ngày!<br />Số lượng click cần phải thực hiện còn: <b>-REM- clicks</b>';
$lang['b_226'] = 'Hình thức giao dịch';
$lang['b_227'] = 'Resend activation email?';
$lang['b_228'] = '<b>Lỗi:</b> You have to be registered for at least -DAYS- days to use this feature!';
$lang['b_229'] = 'Remember me';
$lang['b_230'] = 'Người đã sử dụng!';
$lang['b_231'] = 'Only VIP members can transfer Vcoin!';
$lang['b_232'] = 'Transfer Vcoin';
$lang['b_233'] = 'Thêm banner quảng cáo';
$lang['b_234'] = 'Only VIP members can add banner ads!';
$lang['b_235'] = 'Are you sure you want to report this page?';
$lang['b_236'] = 'Page was Thành Công reported!';
$lang['b_237'] = 'An unexpected Lỗi occurred!';
$lang['b_239'] = 'Thành viện tích cực';
$lang['b_240'] = 'or pay with Vcoin';
$lang['b_241'] = '<b>Thành Công!</b> Thank you for your purchase!';
$lang['b_242'] = 'Get clicks based on Country & Gender';
$lang['b_243'] = '<b>Lỗi:</b> You have to be registered for at least -DAYS- days to withdraw money!';
$lang['b_244'] = 'Commission Paid?';
$lang['b_245'] = 'Subscribe to Newsletter:';
$lang['b_246'] = 'VIP Days';
$lang['b_247'] = 'Đã thực hiện';
$lang['b_248'] = 'Item';
$lang['b_249'] = 'Price';
$lang['b_250'] = 'Không có dữ liệu nào!';
$lang['b_251'] = 'Để nhận được hoa hồng, giới thiệu của bạn phải hoàn thành ít nhất -NUM- trao đổi tại trang web của chúng tôi';
$lang['b_252'] = 'Limit reached! You can\'t have more than -NUM- active reports!';
$lang['b_253'] = 'Please enter a valid amount!';
$lang['b_254'] = 'You have to add at least -MIN-!';
$lang['b_255'] = 'Số dư tài khoản';
$lang['b_256'] = 'Nạp tiền $';
$lang['b_257'] = '10 giao dịch gần nhất';
$lang['b_258'] = 'Gateway';
$lang['b_259'] = 'Hoàn Thành';
$lang['b_260'] = 'Đang xem xét';
$lang['b_261'] = 'Số dư tài khoản: -NUM-';
$lang['b_262'] = '<b>Lỗi:</b> This pack doesn\'t exists!';
$lang['b_263'] = '<b>Lỗi:</b> Bạn không đủ tiền $ để nạp thêm Vcoin,!';
$lang['b_264'] = '<b>Thành Công:</b> -NUM- were added on your account!';
$lang['b_265'] = 'Số Vcoin tối thiểu để đổi là: <b>-MIN- Vcoin</b>!';
$lang['b_266'] = 'You have Thành Công converted <b>-NUM- Vcoin</b> into <b>-CASH-</b>!';
$lang['b_267'] = 'Đổi Vcoin ra tiền';
$lang['b_268'] = 'Đổi Vcoin ra tiền $';
$lang['b_269'] = 'Bạn sẽ nhận được';
$lang['b_270'] = '<b>Thành Công:</b> You have received <b>-NUM- VIP days</b>!';
$lang['b_271'] = 'Top 15 Referrers';
$lang['b_272'] = 'User';
$lang['b_273'] = 'Active Referrals';
$lang['b_274'] = 'This Month';
$lang['b_275'] = 'All times';
$lang['b_276'] = 'Delete Account';
$lang['b_277'] = 'Please tell us why do you want to report this page:';
$lang['b_278'] = 'Lập lại Email';
$lang['b_279'] = '<b>Lỗi:</b> Email addresses don\'t match!';
$lang['b_280'] = 'Comments are temporarily disabled!';
$lang['b_281'] = 'You must be logged in to post comments!';
$lang['b_282'] = '<b>Lỗi:</b> Your comment must have between 20 and 255 characters!';
$lang['b_283'] = 'Author';
$lang['b_284'] = 'Comments';
$lang['b_285'] = 'Write a Comment';
$lang['b_286'] = 'Read more...';
$lang['b_287'] = 'Thông báo';
$lang['b_288'] = '<b>Lỗi:</b> Please wait 60 seconds before posting other comment!';

$lang['footer_desc'] = '<span style="color:#F90; font-weight:bold;">Like càng nhiều, càng thích!</span>';

/* Index description */
$lang['index_desc_1'] = '<h2><font color="#ffffff">Quy định của chúng Tôi:</br></font></h2>
<ol>
	<li>Chúng tôi không bán theo, thích, bạn bè, xem hoặc truy cập trang của bạn dưới bất cứ hình thức nào.</li>
	<li>Chúng tôi tuân thủ  <b>Nội quy Twitter\'s</b> và <b>Chính sách Facebook\'s</b>.</li>
	<li>Chúng tôi sẽ không bao giờ hỏi mật khẩu của bạn cho bất kỳ tài khoản mạng xã hội của bạn.</li>
        <li><b>Tăng like facebook, Tăng like miễn phí, kiếm tiền online</b>.</li>
</ol>';
$lang['b_289'] = 'Nạp tiền';
$lang['b_290'] = 'Tải game mobile';
$lang['b_291'] = 'Thẻ cào';
$lang['b_292'] = 'Rao vặt';
$lang['b_293'] = 'Diễn đàn';
?>
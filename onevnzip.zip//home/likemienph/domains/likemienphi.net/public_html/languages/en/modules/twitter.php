<?
if(! defined('BASEPATH') ){ exit('Unable to view file.'); }

$lang['twt_01'] = 'Twitter Account';
$lang['twt_02'] = 'Twitter Username';
$lang['twt_03'] = 'Twitter already exist!';
$lang['twt_04'] = 'Twitter successfully added!';
$lang['twt_05'] = 'Twitter says';
$lang['twt_06'] = 'Twitter doesn\'t exist!';
$lang['twt_07'] = 'CPC successfully changed!';
$lang['twt_08'] = 'Change CPC';
$lang['twt_09'] = 'Followers received';
$lang['twt_10'] = 'If you don\'t add your real twitter username, used on exchange, you can\'t earn coins.';
$lang['twt_11'] = 'Press "Follow" on this page and after that press "Follow" on twitter page. After that close opened window.';
$lang['twt_12'] = 'Follow';
$lang['twt_13'] = 'Follow user and after that close window!';
$lang['twt_14'] = 'skip';
$lang['twt_15'] = 'Add your Twitter account first!';
$lang['twt_16'] = 'SUCCESS! You skipped this user!';
$lang['twt_17'] = 'Twitter says you aren\'t following this user!';
$lang['twt_18'] = 'SUCCESS!';
$lang['twt_19'] = ' coins were added to your account!';
?>
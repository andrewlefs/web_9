<?
if(! defined('BASEPATH') ){ exit('Unable to view file.'); }

$lang['likepin_01'] = 'URL must be something like: http://pinterest.com/pin/<b>PIN-ID</b>';
$lang['likepin_02'] = 'Pin already added!';
$lang['likepin_03'] = 'This pinterest pin doesn\'t exists!';
$lang['likepin_04'] = 'Pin was successfully added!';
$lang['likepin_05'] = 'Like';
$lang['likepin_06'] = 'Confirm';
$lang['likepin_07'] = 'skip';
$lang['likepin_08'] = 'Like pin and close opened window...';
$lang['likepin_09'] = 'We cannot contact pinterest...';
$lang['likepin_10'] = 'SUCCESS!';
$lang['likepin_11'] = ' <b>coins</b> were added to your account!';
$lang['likepin_12'] = 'Pinterest says you haven\'t liked this pin!';
$lang['likepin_13'] = 'SUCCESS! You skipped this pin!';

// Add Page
$lang['likepin_url'] = 'Pin URL';
$lang['likepin_url_desc'] = 'Add your pin url here';
?>
<?
if(! defined('BASEPATH') ){ exit('Unable to view file.'); }

$lang['retwt_01'] = 'Page was successfully added!';
$lang['retwt_02'] = 'Page already added!';
$lang['retwt_03'] = 'SUCCESS! You skipped this page!';
$lang['retwt_04'] = 'ERROR! Already tweeted!';
$lang['retwt_05'] = 'SUCCESS! You have received <b>-NUM- coins</b>!';

// Add Page
$lang['retwt_url'] = 'URL';
$lang['retwt_title'] = 'Text';
$lang['retwt_url_desc'] = 'Add your website url here';
$lang['retwt_title_desc'] = 'Twitter tweet\'s text';
?>
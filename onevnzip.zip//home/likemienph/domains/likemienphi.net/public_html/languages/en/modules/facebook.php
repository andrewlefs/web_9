<?
if(! defined('BASEPATH') ){ exit('Unable to view file.'); }

$lang['fb_01'] = 'You cannot add Facebook photos!';
$lang['fb_02'] = 'Page was successfully added!';
$lang['fb_03'] = 'SUCCESS! You skipped this page!';
$lang['fb_04'] = 'SUCCESS! You have received <b>-NUM- coins</b>!';
$lang['fb_05'] = 'Page already added!';
$lang['fb_06'] = 'ERROR! You have to be logged in to receive coins!';
$lang['fb_07'] = 'Like page and close opened window...';
$lang['fb_08'] = 'We cannot contact facebook...';
$lang['fb_09'] = 'Facebook says you haven\'t liked this page!';
$lang['fb_10'] = 'SUCCESS!';
$lang['fb_11'] = ' <b>coins</b> were added to your account!';
$lang['fb_12'] = 'Like';
$lang['fb_13'] = 'Confirm';
$lang['fb_14'] = 'skip';

// Add Page
$lang['fb_url'] = 'URL';
$lang['fb_title'] = 'Title';
$lang['fb_url_desc'] = 'Add your url here';
$lang['fb_title_desc'] = 'Add your page title here';
?>
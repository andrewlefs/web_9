<?php
$titleweb =  'Tăng like Facebook, tang like facebook, tăng like, tang like, like facebook';
include('header.php');
if(!$is_online){?>
<div class="content t-left">
    <h2>Hệ thống Facebook Likes, Twitter Followers, Youtube Views, Website hits, Re-Tweets và Google +1  tất cả đều miễn phí.</h2>
    <p>Like miễn phí là một công cụ sẽ giúp bạn phát triển Facebook, Twitter, Google, YouTube và trang web của bạn một cách tốt nhất. Likemienphi.Net cho phép bạn có toàn quyền sử dụng một cách dễ ràng nhất, bạn có quyền Like, follow những Facebook hoặc những người bạn và website mà bạn muốn, nếu không muốn bạn có thể nhấn vào bỏ qua.</p>
    <center><img src="up/change-fb-like-en.jpg" alt="Like Exchange" width="600px"></center>
    <h3>Facebook Likes</h3>
   <p>Với xu hướng hiện nay facebook là một phần không thể thiếu trong seo website, là một phần của kinh doanh, là một phần của vui chơi, trao đổi, giải trí và là thước đo cho sự tin tưởng với bạn hay công ty bạn.</p>
<p>Hãy tưởng tượng bạn nhìn thấy hai trang Facebook, Trang đâu tiên dưới 10 người like, nhưng trang thứ hai có một vài ngàn hoặc thậm chí hàng chục ngàn người like.</p>
<p>Chắc chắn bạn sẽ thích và tin tưởng trang đã có nhiều người like, like cho uy tín và sự bổ ích từ trang facebook đó, nhưng bạn có biết để phát triển mời được 1000 người thích là một điều khóa mất rất nhiều thời gian của bạn, nó giống như một ngưỡng, khi bạn vượt qua ngưỡng này, nó rất dễ dàng cho số lượng người like của bạn để liên tục gia tăng và phát triển. Like Miễn phí sẽ giúp bạn tạo ra bước ngoặc để vượt qua ngưỡng cửa mà bạn muốn. bạn cũng có thể kiếm tiền bằng cách tích thật nhiều Vcoin. Bạn tham gia ngay bây giờ bạn sẽ nhận được 200 Vcoin.</p>
    <center><img src="up/change-sites-flow-en.jpg" alt="Tăng lượt truy cập cho website" width="600px"></center>
    <h3>Website Hits</h3>
    <p>
    Bạn muốn tăng thứ hạng cho website hay blog của bạn? Bạn làm seo chí phí quá cao. Likemienphi.net sẽ giúp bạn tăng thứ hạng website mà không mất chi phí nào cả. 
Hiện tại có một số phương pháp tăng thứ hạng cho website nhưng không phải ai cũng làm được, nhưng với Like miễn phí bạn rất rễ dàng cho việc tăng hạng website. Khi người sử dụng Like miễn phí sử dụng tính năng duyệt web tự động , họ đang sử dụng IP thực sự của máy tính của họ để duyệt trang web của bạn ! Tại thời điểm này sự gia tăng lưu lượng truy cập cũng giống như lưu lượng truy cập công cụ tìm kiếm , mà công cụ tìm kiếm sử dụng để cải thiện thứ hạng trang web của bạn, Bạn vào phần thêm trang và thêm bất cứ website nào bạn muốn dù là web, blog ... . Bằng cách này, người dùng khác sẽ ghé thăm blog hoặc trang web của bạn để có được những " Vcoin " , và sử dụng " Vcion " để làm cho người khác để duyệt trang web của họ. Chúng tôi cung cấp một dịch vụ hoàn toàn miễn phí, Bạn tham gia ngay bây giờ bạn sẽ nhận được 200 Vcoin.
    </p>
     <center><img src="up/change-youtube-view-en.jpg" alt="Tăng lượt xem clip trong youtube" width="600px"></center>
     <h3>YouTube Views</h3>
     <p>
         
     Bạn muốn tăng lượt xem video của bạn trên Youtube? Một đoạn phim hay một bài hát có rất nhiều ý kiến khác nhau, nếu nó hay nó sẽ có rất nhiều người xem. Likemienphi.net sẽ giúp người dùng xem của nhau để tích Vcoin, Bạn xem của tôi và tôi xem của bạn! Hỗ trợ lẫn nhau để tăng lượt xem của nhau. Chúng tôi cũng cấp dịch vụ tăng lượt xem trên Youtube là hoàn toàn miễn phí, tuy nhiên bạn có thể tích Vcoin để trao đôi hoặc đổi $ rút về ngân hàng. Bạn tham gia ngay bây giờ bạn sẽ nhận được 200 Vcoin.
     </p>
<center><img src="up/change-twitter-follower.jpg" alt="Twitter Followers" width="600px"></center>
<h3>Twitter Followers</h3>
    <p>Bạn muốn có nhiều bạn trên Twitter?</p>
    <p>Hãy tham gia ngay để được trao đổi bạn trên Twitter hoàn toàn miễn phí, bạn cũng có thể kiếm tiền bằng cách tích thật nhiều Vcoin. Bạn tham gia ngay bây giờ bạn sẽ nhận được 200 Vcoin.</p>
<center><img src="up/change-google-plus-en.jpg" alt="Google +1" width="600px"></center>
<h3>Google +1</h3>
<p>Google +1 là một yếu tố xếp hạng trong Seo và các dịch vụ tìm kiếm. Thật dễ với Like miễn phí để có lượt +1</p>
<p>Hãy tham gia ngay để được trao đổi google +1 hoàn toàn miễn phí, bạn cũng có thể kiếm tiền bằng cách tích thật nhiều Vcoin.Bạn tham gia ngay bây giờ bạn sẽ nhận được 200 Vcoin.</p>

	<p><?=$lang['index_desc']?></p><br />
	<p><?=$lang['index_desc_1']?></p>
	<div class="exchange_container" style="text-align:center">
		<h2><?=$lang['b_91']?></h2>
		<?=$lang['b_92']?><br />
		<a href="register.php"><?=hook_filter('index_icons_off',"")?></a><br /><br />
		<a class="bbut" href="register.php"><?=$lang['b_165']?></a>
	</div>	
</div>

				
<?php
}else{
$warn_active = 0;
if($data['warn_message'] != ''){
	$warn_active = 1;
	if($data['warn_expire'] < time()){
            $db->Query("UPDATE `users` SET `warn_message`='', `warn_expire`='0' WHERE `id`='".$data['id']."'");
            $warn_active = 0;
	}
}
?>


<div style="position:fixed;left:0; top:150px;">
<a href="http://diendan.hoanggia.net/forum.php" target="_blank"><img src="/img/diendan.png"  width="60px"/></a> <br />
<a href="/blog.php?bid=34" target="_blank">	<img src="/img/khuyenmai.png"  width="60px"/></a> <br />
<a href="/blog.php?bid=17" target="_blank">	<img src="/img/ruttien.png"  width="60px"/></a> <br />


</div>




<div class="content" ><h2 class="title"><?=$lang['b_83'].' '.$data['login']?></h2>


	<?if($warn_active){?>
        <div class="msg" style="margin-bottom:-15px">
                <div class="error"><?=$data['warn_message']?>
                </div>
        </div><?}elseif($site['c_show_msg'] == 1 && $site['c_text_index'] != ''){?>
        <a href="buy.php"><div style=" color:#FF0000; font-weight:bold; font-size:16px;" class="msg" style="margin-bottom:-15px"><div class="info"><?=$site['c_text_index']?></div></div></a><?}?>
	<div style=" padding-top: 5px;">
	<a href="/blog.php?bid=34"><img src="/img/km.JPG" width="615" height="100" /></a>
	</br>
		
		</div>
	<div class="exchange_container">
		<div class="exchange_content">
			<h2><?=$lang['b_84']?></h2>
			<?=$lang['b_85']?><br />
			<?=hook_filter('index_icons_on',"")?><br /><br />
			<a href="edit_acc.php"><div class="exchange_div"><?=$lang['b_86']?></div></a>
			<a href="logout.php"><div class="exchange_div"><?=$lang['b_87']?></div></a>
			<div style="margin-top:10px">
				<b><?=$lang['b_117']?></b><br /> <input class="text big" type="text" value="<?=WEB_DOMAIN?>/?ref=<?=$data['id']?>" size="40" onclick="this.select()" readonly="true" />
			</div>
		</div>
		<div class="earnings"><?=lang_rep($lang['b_88'], array('-NUM-' => '<span class="ic-count">'.number_format($data['coins']).'</span>')).' '.lang_rep($lang['b_89'], array('-SUM-' => '<a href="bank.php" style="color:green;">'.get_currency_symbol($site['currency_code']).''.$data['account_balance'].'</a>'))?>!</div>
</div>			
</div>

<?php
if($site['fb_fan_url'] != ''){  
    
?>
<div id="fb-root"></div>
<script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) return;
  js = d.createElement(s); js.id = id; js.async = true;
  js.src = "//connect.facebook.net/en_US/all.js#xfbml=1";
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script>
<div style="margin:0 0 5px 0px;float:right;position:relative;border:1px solid #000;border-radius:8px;background:#17262d;width:700px;">
	
	<div style="overflow:hidden;position:relative;width:675px;height:260px;border:1px solid #CCCCCC;display:inline-block;border-radius:10px;margin:10px;">
		<div style="position:absolute;">
			<div class="fb-like-box" data-href="https://www.facebook.com/likemienphi.net?ref=hl" data-width="675" data-colorscheme="" data-show-faces="true" data-header="true" data-stream="false" data-show-border="true"></div>
		</div>
	</div>
</div>
<?php
    }
}
include('footer.php');
?>